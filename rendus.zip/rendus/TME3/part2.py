import part1 as p1
import time

def loadAsList(file):
    f = open(file)
    separator = "\t"
    if(file == p1.file1):
        separator = " "
    l = []
    for line in f :
        nodes = line[:len(line)-1].split(separator)
        l.append((nodes[0],nodes[1]))

    f.close()
    return l

def loadAsMatrix(file):
    f = open(file)
    nb_nodes = p1.sizeOfGraph(file)[1]
    mat = [[0 for i in range(nb_nodes)] for i in range(nb_nodes)]
    index = dict()
    cur_index = 0
    separator = "\t"
    if(file == p1.file1):
        separator = " "

    for line in f:
        nodes = line[:len(line)-1].split(separator)
        n1 = int(nodes[0])
        n2 = int(nodes[1])
        if n1 not in index.keys():
            index[n1] = cur_index
            cur_index+=1
        if n2 not in index.keys():
            index[n2] = cur_index
            cur_index+=1
    f.close()

    f = open(file)
    for line in f:
        nodes = line[:len(line)-1].split(separator)
        n1 = int(nodes[0])
        n2 = int(nodes[1])
        print(n1,n2)
        mat[index[n1]][index[n2]] = 1
        mat[index[n2]][index[n1]] = 1

    f.close()
    return mat,index

def loadAsAdjacencyList(file):

    d = dict()
    f=open(file)
    separator = "\t"
    if(file == p1.file1):
        separator = " "

    for line in f:
        if line.startswith("#"):
            continue
        nodes = line[:len(line)-1].split(separator)
        n1 = int(nodes[0])
        n2 = int(nodes[1])
        if not n1 in d.keys():
            d[n1] = list()
        if not n2 in d.keys():
            d[n2] = list()
        d[n1].append(n2)
        d[n2].append(n1)

    f.close()
    return d


def main():
    t1 = time.time()
    mat = loadAsMatrix(p1.file1)
    t2 = time.time()
    print(t2-t1)

# main()
