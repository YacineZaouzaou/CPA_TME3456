import collections as coll
import time
import part1 as p1
import part2 as p2

def countTriangles(file):
    neighbors = p2.loadAsAdjacencyList(file)
    t1 = time.time()
    for key in neighbors.keys():
        neighbors[key] = sorted(neighbors[key])

    degrees = p1.getDegrees(file)
    sortedDegrees = coll.OrderedDict(sorted(degrees.items(), key=lambda kv: kv[1]))
    cpt_trg = 0
    cpt_trp = 0

    for u in list(sortedDegrees.keys()):
        for i in range(len(neighbors[u])):
            v = (neighbors[u])[i]
            if v>u :
                break
            l1 = (neighbors[u])[:i]
            l2 = []
            for j in neighbors[v]:
                if j>v :
                    break
                l2.append(j)
            c = nbCommonVals(l1,l2)
            cpt_trg+=c
            c = nbCommonVals(neighbors[u],neighbors[v])
            cpt_trp+=(len(neighbors[u])+len(neighbors[v])-c)
    ratio = (3*cpt_trg)/cpt_trp
    t2 = time.time()
    t=t2-t1
    print("The number of triangles : "+str(cpt_trg))
    print("Transitivity Ratio : "+str(ratio))
    f = open("triangles.txt","a")
    f.write("File : "+file+"\n")
    f.write("The number of triangles : "+str(cpt_trg)+"\n")
    f.write("Transitivity Ratio : "+str(ratio)+"\n")
    f.write("Time : "+str(t)+"\n\n")

    return cpt_trg

def nbCommonVals(p,q):
    s = set(p)
    t = set(q)
    return len(s.intersection(t))


def main(files):
    for f in files:
        countTriangles(f)


main(p1.files)
