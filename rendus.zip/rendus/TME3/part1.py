import time
import math
import matplotlib.pyplot as plt

def sizeOfGraph(file):
    f = open(file)
    nodes = set()
    size = 0
    separator = "\t"
    if(file == file1):
        separator = " "
    for l in f:
        if(not l.startswith("#")):
            size+=1
            line = l[:len(l)-1].split(separator)
            n1 = int(line[0])
            n2 = int(line[1])
            nodes.add(n1)
            nodes.add(n2)
    print("File : "+file)
    print("nb of edges: "+str(size))
    print("nb of nodes: "+str(len(nodes)))
    f.close()
    return (size,len(nodes))


def getDegrees(file):
    print(file)
    f1 = open(file)
    degrees = {}
    separator = "\t"
    if(file == file1):
        separator = " "

    for l in f1:
        if(not l.startswith("#")):
            line = l[:len(l)-1].split(separator)
            n1 = int(line[0])
            n2 = int(line[1])
            if(degrees.get(n1)==None):
                degrees.update({n1:0})
            degrees[n1]+=1
            if(degrees.get(n2)==None):
                degrees.update({n2:0})
            degrees[n2]+=1

    f1.close()
    if file==file1 : f2 = open("degrees_1.txt","w+")
    if file==file2 : f2 = open("degrees_2.txt","w+")
    if file==file3 : f2 = open("degrees_3.txt","w+")
    if file==file4 : f2 = open("degrees_4.txt","w+")

    for d in degrees.keys():
        f2.write(str(d)+" : "+str(degrees[d])+"\n")
    f2.close()
    return degrees



def specialQ (file,degrees) :
    f = open(file)
    t1 = time.time()
    sum = 0
    separator = "\t"
    if(file == file1):
        separator = " "

    for line in f :
        if(not line.startswith("#")):
            nodes = line[:len(line)-1].split(separator)
            sum += (degrees[int(nodes[0])] * degrees[int(nodes[1])])

    t2 = time.time()
    t = t2-t1
    f.close()
    f2 = open("specialQ_times.txt","a")
    f2.write("File: "+file+"\n")
    f2.write("special quantity : "+str(sum)+"\n")
    f2.write("time : "+str(t)+"\n\n")
    f2.close()

def degreeDistrib(file):
    degrees = getDegrees(file)
    dict = {}
    for key in degrees.keys():
        deg = degrees[key]
        if(deg != 0):
            if(dict.get(deg)==None):
                dict.update({deg:0})
            dict[deg]+=1

    if file==file1 : f = open("degreesDistrib_1.txt","w+")
    if file==file2 : f = open("degreesDistrib_2.txt","w+")
    if file==file3 : f = open("degreesDistrib_3.txt","w+")
    if file==file4 : f = open("degreesDistrib_4.txt","w+")
    for key in dict.keys():
        f.write(str(key)+"\t"+str(dict.get(key))+"\n")
    f.close()

    return dict

def plotDegreeDistrib(file):
    degDistrib = degreeDistrib(file)
    x = [deg for (deg,nb) in degDistrib.items()]
    y = [nb for (deg,nb) in degDistrib.items()]

    plt.plot(x,y)
    plt.xlabel('degree')
    plt.ylabel('nb of nodes')
    if file==file1 : plt.savefig("degDistrib_email.png")
    if file==file2 : plt.savefig("degDistrib_amazon.png")
    if file==file3 : plt.savefig("degDistrib_liveJournal.png")
    if file==file4 : plt.savefig("degDistrib_orkut.png")




file1 = "/Vrac/TME_CPA_19-02-20/email-Eu-core-clean.txt"
file2 = "/Vrac/TME_CPA_19-02-20/com-amazon.ungraph-clean.txt"
file3 = "/Vrac/TME_CPA_19-02-20/com-lj.ungraph-clean.txt"
file4 = "/Vrac/TME_CPA_19-02-20/com-orkut.ungraph-clean.txt"
file5 = "/Vrac/TME_CPA_19-02-20/com-friendster.ungraph.txt"

files = [file1,file2,file3,file4]

def main(files):
    for f in files:
        sizeOfGraph(f)
        degrees = getDegrees(f)
        specialQ(f,degrees)
    plotDegreeDistrib(files[0])


# main(files)
