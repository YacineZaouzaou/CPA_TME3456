
import part1 as p1
import part2 as p2
import collections as coll

def bfs(graph, s):
    mark = {}
    hierarchy = {}
    for k in graph.keys():
        mark[k]=0
    l = coll.deque([s])
    mark[s] = 1
    hierarchy[s] = -1
    last = s
    while(l):
        u = l.popleft()
        for n in graph[u]:
            if mark[n]==0:
                l.append(n)
                mark[n] = 1
                last = n
                hierarchy[n] = u
    res =[i for i in mark.keys() if mark[i]==1]
    return res,hierarchy,last


def getClusters(graph,file):
    clusters = []
    cpt = 0

    while(graph.keys()):
        s = list(graph.keys())[0]
        print("in bfs")
        cl = bfs(graph,s)[0]
        print("out bfs")
        clusters.append(cl)
        cpt+=1
        print("size of the cluster "+str(cpt)+" : "+str(len(cl))+" nodes")
        l = set(graph.keys())-set(cl)
        g=dict()
        for i in l:
            g=graph[i]
        graph = g

    return clusters

def computeFraction(file):
    graph = p2.loadAsAdjacencyList(file)
    size = p1.sizeOfGraph(file)[1]
    print("in getClusters")
    clusters = getClusters(graph,file)
    print("out getClusters")
    max = 0

    for i in range(len(clusters)):
        if len(clusters[i])>max:
            max = len(clusters[i])
    fraction = max/size
    f = open("Fractions.txt","a")
    f.write("File : "+file+"\n")
    f.write("The fraction of the largest connected component is : "+str(fraction)+"\n\n")
    print(fraction)
    return fraction

def getDiameter(ss_graph):
    res,hierarchy,last = bfs(ss_graph,list(ss_graph.keys())[0])
    n1 = last
    res,hierarchy,last = bfs(ss_graph,n1)
    n1 = last
    res,hierarchy,last = bfs(ss_graph,last)
    cur = last
    cpt = 0
    while(cur != n1):
        cpt+=1
        cur = hierarchy[cur]

    return cpt

def lowerBoundDiameter(file):
    graph = p2.loadAsAdjacencyList(file)
    clusters = getClusters(graph.copy(),file)
    diameters = []

    # computes the largest component
    for cl in clusters:
        ss_graph = {}
        for i in cl:
            ss_graph[i] = graph[i]
        diameters.append(getDiameter(ss_graph))
    lb = min(diameters)
    f = open("Lower_bound.txt","a")
    f.write("File : "+file+"\n")
    f.write(str(lb)+"\n\n")
    print(lb)
    return lb


def main(files):
    for f in files:
        lowerBoundDiameter(f)
        # computeFraction(f)


# main(p1.files)
