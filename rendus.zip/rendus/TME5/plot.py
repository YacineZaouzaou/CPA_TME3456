import time
import numpy as np
import matplotlib.pyplot as plt
import pageRank as pr


def plot1(d_in,d_out,a,t):
    P,index = pr.PowerIter(d_out,a,t)

    p = [(node,P[arg]) for (node,arg) in index.items()]
    p.sort(key=lambda k:k[1])
    x=[pr for (node,pr) in p]
    y=[len(d_in[node]) for (node,pr) in p]

    plt.scatter(x,y)
    plt.xlabel('PageRank')
    plt.ylabel('in_degree')
    plt.xlim(0,0.004)
    plt.savefig('plot1.png')


def plot2(d,a,t):
    P,index = pr.PowerIter(d,a,t)

    p = [(node,P[arg]) for (node,arg) in index.items()]
    p.sort(key=lambda k:k[1])
    x=[pr for (node,pr) in p]
    y=[len(d[node]) for (node,pr) in p]

    plt.scatter(x,y)
    plt.xlabel('PageRank')
    plt.ylabel('out_degree')
    plt.xlim(0,0.005)
    plt.savefig('plot2.png')


def otherPlots(d,a1,a2,t):
    P1,index = pr.PowerIter(d,a1,t)
    P2,index = pr.PowerIter(d,a2,t)
    args = np.argsort(P1)
    args = np.argsort(P2)
    x = np.array([P1[a] for a in args])
    y = np.array([P2[a] for a in args])

    plt.scatter(x,y)
    plt.xlabel('PageRank with a='+str(a1))
    plt.ylabel('PageRank with a='+str(a2))
    plt.xlim(0,0.002)
    plt.ylim(0,0.002)
    plt.savefig('plot_'+str(a1)+'_'+str(a2)+'.png')

t1 = time.time()
d_out = pr.readHyperlinks("./data/alr21--dirLinks--enwiki-20071018.txt")
otherPlots(d_out,0.15,0.1,4)
t2 = time.time()
print(t2-t1)
