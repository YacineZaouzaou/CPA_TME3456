import time
import numpy as np


def readHyperlinks(file):
    d = dict()
    f=open(file)
    for line in f:
        if line.startswith("#") or line=="\n":
            continue
        nodes = line[:len(line)-1].split("\t")
        n1 = int(nodes[0])
        n2 = int(nodes[1])
        if not n1 in d.keys():
            d[n1] = list()
        if not n2 in d.keys():
            d[n2] = list()
        d[n1].append(n2)

    f.close()
    return d


def readHyperlinksIn(file):
    d = dict()
    f=open(file)
    for line in f:
        if line.startswith("#") or line=="\n":
            continue
        nodes = line[:len(line)-1].split("\t")
        n1 = int(nodes[0])
        n2 = int(nodes[1])
        if not n1 in d.keys():
            d[n1] = list()
        if not n2 in d.keys():
            d[n2] = list()
        d[n2].append(n1)

    f.close()
    return d


def readPagesNames(file):
    d = dict()
    f=open(file)
    for line in f:
        if line.startswith("#") or line=="\n":
            continue
        nodes = line[:len(line)-1].split("\t")
        n1 = int(nodes[0])
        n2 = nodes[1]
        d[n1]=n2

    f.close()
    return d


def matVectProd(d,p,index):
    n = len(p)
    b = []
    l = list(d.keys())

    for i in range(n):
        b.append(0)

    for i in range(n):
        h = d[l[i]]
        for j in h:
            b[index[j]]+=(1/len(h))*p[index[l[i]]]

    return b


def PowerIter(d,a,t):
    keys = list(d.keys())
    n = len(keys)
    I = []
    P = []
    index = dict()
    for i in range(n):
        I.append(1/n)
        P.append(1/n)
        index[keys[i]] = i

    for i in range(t):
        P = matVectProd(d,P,index)
        P = list(((1-a)*np.array(P)+a*np.array(I)))
        s = sum(P)
        for j in range(n):
            P[j]+=(1-s)/n

    return P,index


def highestAndLowestPR(P,index,d):
    args = np.argsort(P)
    n = len(args)
    highest = [(key,P[arg]) for (key,arg) in index.items() if arg in args[n-5:]]
    lowest = [(key,P[arg]) for (key,arg) in index.items() if arg in args[:5]]
    highest.sort(key=lambda tup: tup[1],reverse=True)
    lowest.sort(key=lambda tup: tup[1])
    h = [d[id] for (id,val) in highest]
    l = [d[id] for (id,val) in lowest]
    print(h)
    print(l)


t1 = time.time()
d = readHyperlinks("./data/alr21--dirLinks--enwiki-20071018.txt")
# d_in = readHyperlinksIn("./data/alr21--dirLinks--enwiki-20071018.txt")
# names = readPagesNames("./data/alr21--pageNum2Name--enwiki-20071018.txt")
P,index = PowerIter(d,0.15,8,names)
# highestAndLowestPR(P,index,names)
t2 = time.time()
print(t2-t1)
