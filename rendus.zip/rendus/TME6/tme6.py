from reader_writer import readToAdjList as reader
from reader_writer import readToListEdge as reader_edge
from reader_writer import writeDegrees as writer
from reader_writer import getNumberNodes as getSize
from reader_writer import readKcore
from reader_writer import readResult
from util_graph import toEdgeList
from util_graph import coreNodes
from util_graph import getNbEdge
from reader_writer import readToAdjList_liste as reader_liste
import matplotlib.pyplot as plt

import heapq
import sys
import os
import time
import gc
import collections
import operator

# k-core decomposition implementation 

def get_the_least_connnected (adjList) :
    key = list(adjList.keys())[0]
    val = len (adjList[key])
    node = key
    for k in adjList.keys() : 
        if len (adjList[k]) < val :
            node = k
            val = len(adjList[k])
    return node

def remove_val (adjList, key) : 
    for k in adjList[key] : 
        adjList[k].remove(key)
    del adjList[key]
    return adjList

def get_max (val1 , val2) :
    if val1 < val2 : 
        return val2
    return val1

def decompose (path) : 
    adjList = reader(path)
    core = dict()
    c = 0
    while len (adjList) > 0 : 
        li = [ (len(j),i) for i,j in adjList.items()]
        minimum = min(li)
        l = minimum[1]
        deg = len (adjList[l])
        adjList = remove_val(adjList, l)
        c = max ([c , deg])
        core[l] = c
    return core

def getDegs (adjList) : 
    degs = dict()
    listDegs = list()
    for k in adjList.keys() : 
        if len(adjList[k]) not in degs.keys() :
            degs[len(adjList[k])] = list()
            listDegs.append(len(adjList[k]))
        degs[len(adjList[k])].append(k)
         
    return listDegs, degs

def remove_val_opt(adjList, degs , l): 
    for k in adjList[l] : 
        degs[len(adjList[k])].remove(k)
        if len (degs[len(adjList[k])]) == 0 : 
            del degs[len(adjList[k])]
        if len(adjList[k])-1 not in degs.keys() : 
            degs[len(adjList[k])-1] = list()
        degs[len(adjList[k])-1].append(k)
        adjList[k].remove(l)
    degs[len(adjList[l])].remove(l)
    if len(degs[len(adjList[l])]) == 0 : 
        del degs[len(adjList[l])]
    del adjList[l]
    return adjList , degs

def decompose_opt (path) : 
    adjList = reader(path)
    core = dict()
    c = 0
    degs = getDegs(adjList)[1]
    while len (adjList) > 0 : 
        l = degs[min(degs.keys())][0]
        deg = len(adjList[l])
        adjList , degs = remove_val_opt(adjList , degs , l)
        c = get_max (c , deg)
        core[l] = c
    return core


# writer(decompose_opt(sys.argv[1]), "scholarSetCore.txt")


# trying to optimise more : 


def getDegs_opt2 (adjList) : 
    degs = dict()
    for l in adjList.keys() : 
        if len(adjList[l]) not in degs.keys() : 
            degs[len(adjList[l])] = set()
        degs[len(adjList[l])].add(l)
    return degs

def remove_val_opt2 (adjList , degs, k) : 
    deg = len(adjList[k]) - 1
    if len(degs[deg+1]) == 0 : 
        del degs[deg+1]
    for v in adjList[k] : 
        degs[len(adjList[v])].discard(v)
        if len (degs[len(adjList[v])]) == 0 :
            del degs[len(adjList[v])] 
        if len(adjList[v]) - 1 not in degs.keys() :
            degs[len(adjList[v]) - 1] = set()
        degs[len(adjList[v]) - 1].add(v)
        adjList[v].discard(k)
    del adjList[k]
    return adjList , degs

    

def decompose_opt2 (path) : 
    adjList = reader_liste(path)
    core = dict()
    c = 0
    degs = getDegs_opt2 (adjList)
    
    while len(adjList) > 0 : 
        l = degs [min(degs.keys())].pop()
        deg = len(adjList[l])
        adjList , degs = remove_val_opt2(adjList , degs , l)
        c = get_max(deg , c)
        core[l] = c
    
    return core

# end of trying




def getDegs_3 (adjList) : 
    degs = set() 
    for k in adjList.keys() : 
        degs.add(len(adjList[k]))
    return degs

def getOneMin (adjlist , degs) : 
    item = min(degs)
    while (len(degs) != 0) :
        for k in adjlist.keys () :
            if len(adjlist[k]) == item : 
                return k , degs
        degs.discard(item)
        item = min(degs)

def remove_val_opt3(adjlist , degs , l) : 
    for v in adjlist[l] : 
        adjlist[v].remove(l)
        degs.add(len(adjlist[v]))
    del adjlist[l]
    return adjlist , degs

def decompose_opt3 (path) : 
    adjList = reader(path)
    core = dict()
    c = 0 
    degs = getDegs_3(adjList)
    while len(adjList) > 0 : 
        l , degs = getOneMin(adjList , degs)
        c = get_max(c , len(adjList[l]))
        core [l] = c
        adjList, degs = remove_val_opt3 (adjList ,degs ,  l)
    return core

# the average dergee density 

def averageDegree (adjList) :
    total = 0
    for k in adjList.keys() : 
        total = total + len(adjList[k])
    total = total / 2
    return total / len(adjList)

def avDD (adjList) : 
    avDeg = averageDegree (adjList)
    return avDeg / 2

# the edge density

def edgeDensityCalculus (edgeList , nb_node) : 
    return len(edgeList)/((nb_node*(nb_node -1))/2)

def edgeDensity (adjList) : 
    edgesList = toEdgeList(adjList)
    return edgeDensityCalculus(edgesList , len(adjList))

def edgeDensity_heavy(adjList) : 
    nbEdge = getNbEdge(adjList)
    nb_node = len(adjList)
    if nb_node <= 1 :
        d = 1
    else :
        d = ((nb_node*(nb_node - 1))/2)
    return nbEdge/d

# the size of a densest core ordering prefix


def getcores (core , k) :
    cores = list()
    for l in core.keys() : 
        if l >= k :
            for elem in core[l] :  
                cores.append(elem)
    return cores

def getGraphe (graphe , core ,node_core,  adjList , k) :
    for v in core[k] :
        if v not in graphe.keys() :  
            graphe[v] = list()
        for elem in adjList[v] : 
            if node_core[elem] >= k : 
                if elem not in graphe[v] :
                    graphe[v].append(elem)
                if elem in graphe.keys() :
                    if v not in graphe[elem] :
                        graphe[elem].append(v)
        del adjList[v]
    return graphe , adjList

def testGetGraph (path) :
    adjList = reader(path)
    core = coreNodes(decompose_opt(path))
    print(adjList)
    print(core)
    print(getGraphe(dict(),core , dict(),adjList , 3))

# testGetGraph(sys.argv[1])


def getTheMaxAvDD (avddDec) : 
    k = list(avddDec.keys())[0]
    val = avddDec[k]
    for key in avddDec : 
        if avddDec [key] > val : 
            k = key
            val = avddDec[key]
    return k , val

def collectGarbageAdjList (listToDel , adjList) : 
    for elem in listToDel : 
        del adjList[elem]
    return adjList

#####################################
#          to del                   #
#####################################

def getSizeMo (myDict):
    size = 0
    for k in myDict.keys() : 
        size = size + sys.getsizeof (myDict[k])
    size = size + sys.getsizeof(myDict)
    return (size / (1024 * 1024))


#####################################
#          end to del               #
#####################################




# it writes k size avDD edgeDens


def sizeDCOP (dest_path , core , node_core , adjList) :
    g = dict ()
    retval = -1
    retk = -1
    s = sorted (core.keys() , reverse = True)
    fic = open(dest_path , "w")
    for k in s :
        print(" k = ",k)
        g , adjList = getGraphe (g , core ,node_core,  adjList, k)
        val1 = avDD(g)
        val2 = edgeDensity_heavy(g) 
        print("densitity : ", val1)
        print("size core : ", len(core))
        print("size node_core : ", len(node_core))
        fic.write(str(k))
        fic.write(" ")
        fic.write(str(len(core[k])))
        fic.write(" ")
        fic.write(str(val1))
        fic.write(" ")
        fic.write(str(val2))
        fic.write("\n")
        del core[k]
    fic.close()
    return retk , retval



def getDensest (path) : 
    res = readResult(path)
    score = dict()
    ordre_size = collections.OrderedDict(sorted(res.items() , key = lambda k : k[1][0]))
    ordre_avdd = collections.OrderedDict(sorted(res.items() , key = lambda k : k[1][1]))
    i = 0
    for v in ordre_size : 
        score[v] = i
        i = i + 1
    i = 0
    for v in ordre_avdd : 
        score[v] = score[v] + i 
        i = i + 1
    k = max (score.items() , key = operator.itemgetter(1))[0]
    print (k, " ", res[k])
    f = open (path , "a")
    f.write("\n\n\n\n")
    f.write("# ")
    f.write(str(k))
    f.write(" ")
    f.write(str(res[k]))
    f.write("\n")
    f.close()
    
# getDensest(sys.argv[1])


# adjList = reader(sys.argv[1])
# n_c = decompose_opt(sys.argv[1])
# print (sizeDCOP(coreNodes(n_c),n_c, adjList))

def recup_values (graphe_path , core_path , dest_path):
    print("starting recup_value...")
    core = readKcore(core_path)
    print("core got")
    k , v = sizeDCOP(dest_path ,  coreNodes(core) ,core , reader(graphe_path))
    print("k and v got")


# recup_values(sys.argv[1] , sys.argv[2] , sys.argv[3])



def exo02 (path_graph , path_id) :
    adjlist = reader(path_graph)
    core = decompose_opt3(path_graph)
    y = list()
    x = list()
    max_deg = 0
    id_ = 0
    for k in adjlist : 
        x.append(len(adjlist[k]))
        if len(adjlist[k]) > max_deg : 
            max_deg = len(adjlist[k])
            id_ = k
        y.append(core[k])
    plt.scatter(x , y , c = "blue" , alpha = 1.0)
    plt.title("scholar")
    plt.xlabel("degree")
    plt.ylabel("core")
    # plt.savefig("tentative")
    print(id_)
    # plt.show()

exo02(sys.argv[1] , sys.argv[2])



# while True : 
#     print("enter choice")
#     choix = input()
#     c = int(choix)
#     if c == 1 :
#         adjList  = reader_liste(sys.argv[1])
#         core = readKcore(sys.argv[2])
#     elif c == 2 :
#         print(getSizeMo(adjList))
#         print(getSizeMo(core))
#     elif c == 3 :
#         print("get k to del")
#         choix = input()
#         c = int(choix) 
#         for k in core.keys() : 
#             if k > c :
#                 del adjList[k] 


# print(avDD(reader(sys.argv[1])))






# print(decompose_opt2(sys.argv[1]))


# to run 
# def runner (dirPath , destPath) : 
#     l = os.listdir(dirPath)
#     print(l)
#     for fic in l : 
#         print("starting for file ", fic)
#         writer(decompose_opt(dirPath+"/"+fic) , destPath+"/degree_"+fic)
#         print("ending for file ", fic)

def runner (path , dist) : 
    print("salut")
    writer(decompose_opt2(path), dist)

# runner (sys.argv[1], sys.argv[2])


# print(edgeDensity_heavy(reader(sys.argv[1])))
