from reader_writer import readToListEdge as reader
from reader_writer import readToAdjList as reader_adj
from reader_writer import writeMkScor 
from reader_writer import readMkScor
from tme6 import edgeDensity_heavy
from tme6 import avDD


import sys

def mkscore_adj (path , dest_path , nb_it) : 
    adjlist = reader_adj (path)
    r = dict()
    for k in adjlist.keys() : 
        r[k] = 0 
    t = nb_it
    while t > 0 : 
        print("iteration", t)
        for k in adjlist.keys() : 
            # print("for : ",k)
            for v in adjlist[k] : 
                if k < v : 
                    if r[k] <= r[v] : 
                        r[k] = r[k] + 1
                    else : 
                        r[v] = r[v] + 1
        t = t - 1
    for k in r.keys() : 
        r[k] = r[k] / nb_it
    writeMkScor(dest_path, r)


def mkscore(path , dest_path , nb_it) :
    edgeList = reader(path)
    r = dict()
    for i in edgeList :
        r[i[0]] = 0
        r[i[1]] = 0
    t = nb_it
    while nb_it > 0 : 
        print("iteration ")
        for edge in edgeList :
            if r[edge[0]] <= r[edge[1]] :
                r[edge[0]] = r[edge[0]] + 1
            else : 
                r[edge[1]] = r[edge[1]] + 1
        nb_it = nb_it - 1
    for k in r.keys() : 
        r[k] = r[k] / t
    writeMkScor(dest_path, r)


def loadGraph (adjlist , score) :
    d = dict() 
    for v in score : 
        if v not in d.keys() : 
            d[v] = set()
        for n in adjlist[v] : 
            if n in score : 
                d[v].add(n)
            else :
                d[v].add(v)
    return d

def ecrit(dest , k , l , avd , ed) : 
    dest.write(str(k))
    dest.write(" ")
    dest.write(str(l))
    dest.write(" ")
    dest.write(str(avd))
    dest.write(" ")
    dest.write(str(ed))
    dest.write("\n")

def run (graphe_path , score_path , res_path) : 
    adjList = reader_adj(graphe_path)
    score = readMkScor(score_path)
    dest = open(res_path , "a")
    i = 0
    for k in score.keys() : 
        print("loading : ", i , " from ", len(score))
        i = i + 1
        g = loadGraph(adjList , score[k])
        avd = avDD(g)
        ed = edgeDensity_heavy(g)
        ecrit (dest , k , len(g) , avd , ed)
    dest.close()

run(sys.argv[1] ,sys.argv[2] ,sys.argv[3])

# mkscore_adj(sys.argv[1] , sys.argv[2], int (sys.argv[3]))
# mkscore(sys.argv[1] , sys.argv[2], int (sys.argv[3]))




