from reader_writer import readToAdjList
import sys

def toEdgeList (adjList) : 
    edges = list ()
    for k in adjList.keys () : 
        for elem in adjList[k] : 
            if k < elem : 
                edges.append([k , elem])
        del adjList[k]
    return edges

def coreNodes (core):
    core_nodes = dict ()
    for k in core.keys() : 
        if core[k] not in core_nodes.keys() : 
            core_nodes[core[k]] = list()
        core_nodes[core[k]].append(k)
    return core_nodes

def getNbEdge (adjList) : 
    nb = 0
    for k in adjList.keys() : 
        nb = nb + len(adjList[k])
    return nb/2

# print(toEdgeList(readToAdjList(sys.argv[1])))