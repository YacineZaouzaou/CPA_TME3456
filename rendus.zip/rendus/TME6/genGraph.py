from reader_writer import readToAdjList
from reader_writer import readKcore

import numpy as np
import matplotlib.pyplot as plt
import sys

def getGraph (core_path , graphe_path) : 
    x = list()
    y = list()
    core = readKcore(core_path)
    fig , ax = plt.subplots()
    graphe = readToAdjList(graphe_path)
    for k in sorted(graphe.keys()) : 
        x.append(len(graphe[k]))
        y.append(core[k])
    pcm = plt.scatter(x , y , s = 50 , c = sorted(graphe.keys()) , alpha = 0.8)
    fig.colorbar(pcm)
    plt.show()
    plt.savefig("tentative1.png")

getGraph(sys.argv[1] , sys.argv[2])