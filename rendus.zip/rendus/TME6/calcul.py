
import sys




f = open (sys.argv[1])
sommeavdd = 0
sommeed = 0
maxdens = 0
sizemaxdens = 0
nb = 0
for l in f: 
    if l[0] == '#' or l[0] == '\n' : continue
    values = l.split(" ")
    print(values[2])
    denscor = float(values[0])
    if denscor > maxdens :
        maxdens = denscor
        sizemaxdens = int(values[1])
    avdd = float(values[2])
    eg = float(values[3])
    sommeavdd = sommeavdd + avdd
    sommeed = sommeed + eg
    nb = nb + 1
f.close()
print((sommeavdd/nb), "  ", (sommeed / nb), "  ", sizemaxdens)