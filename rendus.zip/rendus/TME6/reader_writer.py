
import re
import sys


def readToListEdge (filepath) : 
    f = open (filepath)
    myList = list()
    slicer = re.compile(r"\W+")
    for line in f : 
        if (line[0] == '#') :
            continue
        nodes = slicer.split(line)
        node1 = int(nodes[0])
        node2 = int(nodes[1])
        myList.append([node1 , node2])
    f.close()
    return myList

def getNumberNodes (path) : 
    f = open(path)
    slicer = re.compile(r"\W+")
    nodes_ = set()
    for l in f :
        if l[0] == '#' :
            continue 
        nodes = slicer.split(l)
        node1 = int(nodes[0])
        node2 = int(nodes[1])
        nodes_.add(node1)
        nodes_.add(node2)
    f.close()
    return len(nodes_)

def readToListEdge_withsize (filepath) :
    f = open (filepath)
    myList = list()
    nodes_ = set()
    slicer = re.compile(r"\W+")
    for line in f : 
        if (line[0] == '#') :
            continue
        nodes = slicer.split(line)
        node1 = int(nodes[0])
        node2 = int(nodes[1])
        myList.append([node1 , node2])
        nodes_.add(node1)
        nodes_.add(node2)
    f.close()
    return myList , len(nodes_)

def readToAdjList (filePath) : 
    f = open(filePath)
    adjList = dict()
    slicer = re.compile(r"\W+")
    for line in f : 
        if line[0] == '#' : 
            continue
        nodes = slicer.split(line)
        node1 = int(nodes[0])
        node2 = int(nodes[1])
        if node1 == node2 : 
            continue
        if node1 not in adjList.keys() : 
            adjList[node1] = list()
        if node2 not in adjList.keys() : 
            adjList[node2] = list()
        adjList[node1].append(node2)
        adjList[node2].append(node1)
    f.close()
    return adjList


def readToAdjList_liste (filePath) : 
    f = open(filePath)
    adjList = dict()
    slicer = re.compile(r"\W+")
    i = 0 
    for line in f : 
        i = i + 1
        if i % 1000000 == 0 : 
            print("a lu " , str(int(i/1000000)) , " de lignes")
        if line[0] == '#' : 
            continue
        nodes = slicer.split(line)
        node1 = int(nodes[0])
        node2 = int(nodes[1])
        if node1 == node2 : 
            continue
        if node1 not in adjList.keys() : 
            adjList[node1] = set()
        if node2 not in adjList.keys() : 
            adjList[node2] = set()
        adjList[node1].add(node2)
        adjList[node2].add(node1)
    f.close()
    return adjList


def readKcore (path) : 
    f = open(path)
    cores = dict()
    slicer = re.compile (r"\W+")
    for line in f :
        node_core = slicer.split(line)
        node = int (node_core[0])
        core = int (node_core[1])
        cores[node] = core
    f.close()
    return cores

def readResult (path) : 
    f = open(path) 
    res = dict()
    slicer = re.compile(r" +")
    for l in f : 
        if l[0] == '#' or l[0] == '\n' :
            continue
        values = slicer.split(l)
        res[int(values[0])] = (int(values[1]), float(values[2]))
    f.close()
    return res


def writeDegrees (deco , path) : 
    fic = open(getName(path) , "w")
    for k in deco.keys() : 
        fic.write(str(k))
        fic.write(" ")
        fic.write(str(deco[k]))
        fic.write("\n")
    fic.close()

def getName (path):
    slicer = re.compile(r"/")
    words = slicer.split(path)
    return words[len(words)-1]

def writeMkScor(file_path, r) : 
    f = open(file_path , "w")
    for k in r.keys() : 
        f.write(str(k))
        f.write(" ")
        f.write(str(r[k]))
        f.write("\n")
    f.close()

def readMkScor (file_path) : 
    f = open (file_path)
    r = dict() 
    slicer = re.compile(r" ")
    for l in f : 
        vals = slicer.split(l)
        v1 = int (vals[0])
        v2 = float(vals[1])
        if v2 not in r.keys() :
            r[v2] = set ()
        r[v2].add(v1)
    f.close()
    return r


# print(len(readMkScor(sys.argv[1])))

# tests
# print("start reading")
# print (readToListEdge(sys.argv[1]))
# print (readToAdjList(sys.argv[1]))