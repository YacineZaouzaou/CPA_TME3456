



f = open ("histo.txt")
min_ = 1000
max_ = 0
somme = 0
nb = 0
for l in f : 
	values = l.split(" ")
	v = int(values[1])
	if v < min_ : 
		min_ = v
	if v > max_ : 
		max_ = v
	somme = somme + v
	nb = nb + 1
f.close()
print(max_ , " " , min_ , " " , (somme/nb))
