
import sys
import signal


# f = open("AllGraphFiles/com-youtube.all.cmty.txt")
# i = 0
# for l in f : 
#     f2 = open("AllGraphFiles/com-youtube.all.cmty.txt")
#     for s in f2 : 
#         if s == l : 
#             i = i + 1
#     f2.close()
# f.close()
# print(i)

# valeur = 0


# def ecrire (signal , fram) : 
    

# signal.signal(signal.SIGHUP , ecrire)

