



def color (i) :
    if not type(i) == int :
        return "lime" 
    liste = ["red", "blue" , "green" , "gray" , "maroon" , "yellow" , "purple"]
    return liste[i%len (liste)]

def getMaxX (liste) :
    if len(liste) == 0 :
        return 0
    max = liste[0][0]
    for i in liste :
        if i[0] > max : 
            max = i[0]
    return max


def getMinX (liste) :
    if len(liste) == 0 : 
        return 0
    min = liste[0][0]
    for i in liste : 
        if i[0] < min :
            min = i[0]
    return min


def getMaxY (liste) :
    if len(liste) == 0 :
        return 0
    max = liste[0][1]
    for i in liste :
        if i[1] > max : 
            max = i[1]
    return max


def getMinY (liste) :
    if len(liste) == 0 : 
        return 0
    min = liste[0][1]
    for i in liste : 
        if i[1] < min :
            min = i[1]
    return min


def toSvg (nodes, edges, neighbort) :
    maxX = getMaxX(nodes)
    minX = getMinX(nodes)
    maxY = getMaxY(nodes)
    minY = getMinY(nodes)
    width = maxX + 5
    height = maxY + 5
    print("width = ",width)
    print("height = ",height)
    fic = open ("graph.svg", "w")
    fic.write("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n")
    fic.write("<svg xmlns=\"http://www.w3.org/2000/svg\" version=\"1.1\" width=\"")
    fic.write(str(width))
    fic.write("\" height=\"")
    fic.write(str(height))
    fic.write("\">\n")
    fic.write("<title>Exemple simple de figure SVG</title>\n")
    fic.write("<rect width=\"100%\" height=\"100%\" fill=\"white\"/>")
 
    
    for v in edges :
        fic.write("<line x1=\"")
        fic.write(str(v[0][0]))
        fic.write("\" y1=\"")
        fic.write(str(v[0][1]))
        fic.write("\" x2=\"")
        fic.write(str(v[1][0]))
        fic.write("\" y2=\"")
        fic.write(str(v[1][1]))
        fic.write("\" style=\"stroke:rgb(0,0,0);stroke-width:3\"/>\n")
    
    for v in nodes :
        fic.write("<circle cx=\"")
        fic.write(str(v[0]))
        fic.write("\" cy=\"")
        fic.write(str(v[1]))
        fic.write("\" r=\"5\" fill=\"")
        if v not in neighbort.keys():
            fic.write("lime")
        else :     
            fic.write(color(neighbort[v]))
        fic.write("\"/>\n")



    fic.write("</svg>")
    fic.close()
    









    
