import sys
import random
import networkx as nx
import matplotlib.pyplot as plt



def generateGraphe (p , q , nb_c, nb_p):
    p = float(p)
    q = float(q)
    nb_cluster = int (nb_c)
    nb_pop = int (nb_p)
    nodeList = list()
    for i in range (0 , nb_cluster):
        for j in range (0 , nb_pop):
            nodeList.append((i*nb_pop)+j)
    edgeList = connectNodes (nodeList, p , q, nb_pop)
    return nodeList , edgeList

def connectNodes (liste, p , q , nb_pop) :
    edgeList = list()
    for i in range (0 , len(liste)):
        for j in range (i+1 , len(liste)):
            d = random.uniform (0.0 , 1.0)
            if int (i / nb_pop) == int (j / nb_pop) : 
                if (d <= p):
                    edgeList.append((liste[i], liste[j]))
            else :
                if (d < q):
                    edgeList.append((liste[i],liste[j]))
    return edgeList

def writeGraph (filepath, edgesliste) : 
    f = open(filepath , "w")
    for v in edgesliste : 
        f.write(str(v[0]))
        f.write(" ")
        f.write(str(v[1]))
        f.write("\n")
    f.close()

def generateur (p , q , nbc , nbq , path) : 
    edgeList = generateGraphe(p, q , nbc , nbq)[1]
    lien = str("benchMark_exo1/")+path+str(".txt")
    writeGraph( lien, edgeList)
    adj = toListAdj(edgeList)
    del edgeList
    return adj

def generateur_principal (nb_graphe, nbcd , nbpd , p , q) : 
    nbc = int (nbcd)
    nbp = int (nbpd)
    nb_graphe = int (nb_graphe)
    for i in range (0 , nb_graphe) : 
        generateur (p , q , nbc , nbp , "graphe"+str(nbc*nbp)+".txt")
        nbc = nbc * 2
        nbp = nbp * 10

def toListAdj (liste):
    adjList = dict()
    for v in liste : 
        node1 = v[0]
        node2 = v[1]
        if not node1 in adjList.keys() : 
            adjList[node1] = list()
        if not node2 in adjList.keys() : 
            adjList[node2] = list()
        adjList[node1].append(node2)
        adjList[node2].append(node1)
    return adjList


def drawNetwork (adjList, path) :
    G = nx.Graph()
    G.add_nodes_from(list(adjList.keys()))
    for k in adjList.keys() : 
        for v in adjList[k] : 
            G.add_edge(k , v)
    nx.draw(G, with_labels=True, font_weight='bold')
    lien = str("benchMark_exo1/view/")+path+str(".png")
    plt.savefig(lien)
    plt.show()



def main (p , q , nbc , nbq , name) : 
    g = generateur (p , q , nbc , nbq , name)
    drawNetwork(g , name)


main(float(sys.argv[1]), float(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4]), sys.argv[5])

# generateur(0.1 , 0.005 , 4 , 100, "graphe_4_100_3.txt")

# generateur_principal(sys.argv[1] , sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5])



