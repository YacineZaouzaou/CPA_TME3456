
import re
import sys
import random
import time
import networkx as nx
import matplotlib.pyplot as plt
import operator
import collections

def initial_stat (liste):
    node_label = dict()
    i = 1
    for k in liste.keys() : 
        node_label[k] = i
        i = i + 1
    return node_label


def howMany (nodes_cluster) : 
    liste = set()
    for v in nodes_cluster.keys() : 
        liste.add(nodes_cluster[v])
    return len (liste)


# pas utilisé dans le cas d'une optimisation
def max__ (dic , m) : 
    if len(dic) == 0 : 
        return -1
    r = list()
    for k in dic.keys() : 
        if dic[k] == m :
            r.append(k)
    if len(r) == 0 : 
        return -2
    random.shuffle(r)
    return r[0]

def mostOccuredLabel (node_label, liste, k):
    labels = dict()
    for v in liste[k] :
        if node_label[v] not in labels.keys() : 
            labels[node_label[v]] = 0
        labels[node_label[v]] = labels[node_label[v]] + 1
    m =  max (labels.items() , key = operator.itemgetter(1))[1]
    return max__(labels , m)

def propagation_(adjList) :
    node_label = initial_stat(adjList)
    nb_noeud = len(adjList)
    redo = 0
    cpt = 0
    l = list(adjList.keys())
    while True : 
        new_node_label = dict()
        random.shuffle(l)
        for k in l : 
            i = mostOccuredLabel(node_label , adjList, k)
            new_node_label[k] = i
            if node_label[k] == new_node_label[k] :
                redo = redo + 1    
        node_label = new_node_label
        new_node_label = None
        cpt = cpt + 1
        if redo == nb_noeud : 
            break
        else :
            redo = 0
        if cpt == 150:
            break
    return node_label
    
def laod (path) :
    f = open (path)
    adjList = dict()
    limit = re.compile(r'\W+')
    for line in f :
        if line[0] == '#' :
            continue 
        nodes = limit.split(line)
        node1 = int (nodes[0])
        node2 = int (nodes[1])
        if node1 not in adjList.keys() : 
            adjList[node1] = list()
        if node2 not in adjList.keys() : 
            adjList[node2] = list()
        adjList[node1].append(node2)
        adjList[node2].append(node1)
    f.close()
    return adjList

def testLaod () :
    d = laod(sys.argv[1])
    for k in d : 
        print(k," -> ",d[k]) 

