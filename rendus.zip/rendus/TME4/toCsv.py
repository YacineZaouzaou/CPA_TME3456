
import re as re
import sys as sys

def toCsv (filepath) : 
    src = open(filepath)
    dest = open("csv_"+filepath, "w")
    p = re.compile(r"\W+")
    for l in src : 
        if l[0] == '#' : 
            continue
        values = p.split(l)
        dest.write(values[0])
        dest.write(",")
        dest.write(values[1])
        dest.write("\n")
    src.close()
    dest.close()

toCsv(sys.argv[1])