import random
import sys
from toSvg import toSvg
import plotly.plotly as py
import plotly.graph_objs as go
import networkx as nx
import re
from labelProp import propagation_ as propagation__
import matplotlib.pyplot as plt




# this version puts all nodes of a cluster together in one part
# all nodes in the range 100*n to 100*(n+1) with n in range 0 to 4 of edge list belongs to a cluster n+1 

def generateGraphe (p , q):
    p = float(p)
    q = float(q)
    nodeList = list()
    for i in range (0 , 4):
        for j in range (0 , 100):
            x = i % 2
            y = 0
            if i > 1 :
                y = 1
            nodeList.append(((random.randint(x*500,(x*500)+500)),(random.randint(y*500,(y*500)+500)))) 
    edgeList = connectNodes (nodeList, p , q)
    return nodeList , edgeList

def connectNodes (liste, p , q) :
    edgeList = list()
    for i in range (0 , len(liste)):
        for j in range (i+1 , len(liste)):
            d = random.uniform (0.0 , 1.0)
            if int (i / 100) == int (j / 100) : 
                if (d <= p):
                    edgeList.append((liste[i], liste[j]))
            else :
                if (d < q ):
                    edgeList.append((liste[i],liste[j]))
    return edgeList

def writeGraph (filepath, edgesliste) : 
    f = open(filepath , "w")
    for v in edgesliste : 
        f.write(v[0])
        f.write(" ")
        f.write(v[1])
        f.write("\n")
    f.close()


# not used at all
def createGraph (nodes , edges) :
    edge_trace = go.Scatter(
        x=[],
        y=[],
        line=dict(width=0.5,color='#888'),
        hoverinfo='none',
        mode='lines')
    node_trace = go.Scatter(
        x=[],
        y=[],
        text=[],
        mode='markers',
        hoverinfo='text',
        marker=dict(
            showscale=True,
            colorscale='YlGnBu',
            reversescale=True,
            color=[],
            size=10,
            colorbar=dict(
                thickness=15,
                title='Node Connections',
                xanchor='left',
                titleside='right'
            ),
        line=dict(width=2)))
    for edge in edges:
        x0, y0 = edge[0]
        x1, y1 = edge[1]
        edge_trace['x'] += tuple([x0, x1, None])
        edge_trace['y'] += tuple([y0, y1, None]) 
    for node in nodes:
        x, y = node
        node_trace['x'] += tuple([x])
        node_trace['y'] += tuple([y])
    fig = go.Figure(data = [edge_trace, node_trace], layout = go.Layout())
    py.iplot(fig, filename = 'networkx')

def initialisation_prog (edges) :
    nodes_cluster = dict()
    i = 0
    for v in edges :
        if not (v[0] in nodes_cluster.keys()) : 
            nodes_cluster[v[0]] =  i
            i = i + 1
        if not (v[1] in nodes_cluster.keys()) : 
            nodes_cluster[v[1]] =  i
            i = i + 1
    return nodes_cluster

def shallIredo () :
    return False

def getMax (neighbors) : 
    if len (neighbors) == 0 :
        return -1
    ret = list(neighbors.keys())[0]
    i = neighbors[list(neighbors.keys())[0]]
    for key in neighbors.keys() :
        if neighbors[key] > i : 
            i = neighbors[key]
            ret = key
    return ret

def getLabelOfNeighbor (edges, nodes_cluster , a) :
    neighbors = dict()
    for v in edges :
        if v[0] == a :
            if not (nodes_cluster[v[1]] in neighbors.keys()) : 
                neighbors[nodes_cluster[v[1]]] = 0
            neighbors[nodes_cluster[v[1]]] = neighbors[nodes_cluster[v[1]]] + 1
        if v[1] == a :
            if not (nodes_cluster[v[0]] in neighbors.keys()) : 
                neighbors[nodes_cluster[v[0]]] = 0
            neighbors[nodes_cluster[v[0]]] = neighbors[nodes_cluster[v[0]]] + 1
    
    return getMax(neighbors)



# ce n'est pas du tout le bon nom à donner
def howMany (nodes_cluster) : 
    liste = dict()
    for v in nodes_cluster.keys() : 
        if nodes_cluster[v] not in liste.keys() :
            liste[nodes_cluster[v]] = list()
        liste[nodes_cluster[v]].append(v)
    return liste


def propagation (edges) :
    nodes_cluster = initialisation_prog(edges)
    redo = True
    f = 0
    while redo and f < 100:
        old_size = howMany(nodes_cluster)
        new_nodes_cluster = dict() 
        for v in nodes_cluster.keys() :
            i = getLabelOfNeighbor (edges, nodes_cluster, v)
            if i == -1 : 
                i = nodes_cluster[v]
            new_nodes_cluster[v] = i
        nodes_cluster = new_nodes_cluster
        print(nodes_cluster)
        new_size = howMany(nodes_cluster)
        redo = old_size - new_size
        f = f + 1
        print(f)
    return nodes_cluster

def getGraph (fic) : 
    f = open(fic)
    edges = list()
    limit = re.compile(r'\W+')
    for l in f : 
        if l[0] == '#' :
            continue
        snodes = limit.split(l)
        nodes = [int (snodes[0]) , int (snodes[1])]
        edges.append(nodes)
    f.close()
    return edges


def readToAdjList (path) :
    f = open (path)
    adjList = dict()

    limit = re.compile(r'\W+')
    for line in f :
        if line[0] == '#' :
            continue 
        nodes = limit.split(line)
        node1 = int (nodes[0])
        node2 = int (nodes[1])
        if node1 == node2 :
            continue
        if node1 not in adjList.keys() : 
            adjList[node1] = set()
        if node2 not in adjList.keys() : 
            adjList[node2] = set()
        adjList[node1].add(node2)
        adjList[node2].add(node1)
    f.close()
    return adjList



def color (i) :
    if not type(i) == int :
        return "lime" 
    liste = ["red", "blue" , "green" , "gray" , "maroon" , "yellow" , "purple"]
    return liste[i%len (liste)]


def getEdgeList (adjlist) : 
    l = list()
    for k in adjlist.keys() : 
        for v in adjlist[k] : 
            if k < v : 
                l.append((k , v))
    return l


def drawNetworkColor (adjList, com, path) :
    G = nx.Graph()
    G.add_nodes_from(list(adjList.keys()))
    for k in adjList.keys() : 
        for v in adjList[k] : 
            G.add_edge(k , v)
    
    pos = nx.spring_layout(G)
    i = 0 
    for k in com.keys( ) : 
        nx.draw_networkx_nodes(G ,  pos = pos,node_color= color(i) , nodelist = com[k])
        i = i + 1
    liens = path.split("/")
    lien = liens[len(liens) - 1]
    edgeList = getEdgeList(adjList)
    print(edgeList)
    nx.draw_networkx_edges(G , pos = pos, edge_list = edgeList , alpha=1.0 ,  edge_color="black")
    fin =  len(lien)-4
    plt.savefig(lien[0 :fin])




# Main : 

def main () : 
    liste = readToAdjList(sys.argv[1])
    d = propagation__(liste)
    print("nombre de cluster : ", len(howMany(d)))
    drawNetworkColor(liste, howMany(d), sys.argv[1])

def readD (path) : 
    f = open(path)
    p = re.compile(r"\W+")
    d = dict()
    for l in f : 
        lines = p.split(l)
        d[int(lines[0])] = int(lines[1])
    return d

def mainC () : 
    liste = readToAdjList(sys.argv[1])
    d = readD(sys.argv[2])
    print("nombre de cluster : ", howMany(d))
    drawNetworkColor(liste, howMany(d), sys.argv[1])


def mainYoutube (path) :
    edges = readToAdjList(sys.argv[1])
    d = propagation__(edges)
    s = howMany(d)
    y = list ()
    f = open("histo.txt", "w")
    for k in s : 
        y.append(len(s[k]))
        f.write(str(k))
        f.write(" ")
        f.write(str(len(s[k])))
        f.write("\n")
    f.close()
    x = list(s.keys())
    plt.bar(x , y , width = 1.0 , color = "blue")
    plt.savefig("histo")
    plt.show()
    

def testLaod () :
    dictionnaire = readToAdjList(sys.argv[1]) 
    for l in dictionnaire.keys() :
        print(l," ",dictionnaire[l])

def afficheListAdj (liste) :
    print("length : ", len(liste)) 
    for k in liste.keys () :
        print(k, " -> ",liste[k])


def testAncProp () : 
    liste  = getGraph (sys.argv[1])
    d = propagation(liste)
    print("nombre de cluster : ", howMany(d))
    print()

# mainYoutube(sys.argv[1])
# main()
mainC()
# testLaod()



# priter 
def afficheCoordiante ( edge) :
    for v in edge : 
        print ("(", v[0] ," , ", v[1],")")


def afficheEdges (edges):
    for v in edges : 
        print (v[0] , " -- ", v[1])